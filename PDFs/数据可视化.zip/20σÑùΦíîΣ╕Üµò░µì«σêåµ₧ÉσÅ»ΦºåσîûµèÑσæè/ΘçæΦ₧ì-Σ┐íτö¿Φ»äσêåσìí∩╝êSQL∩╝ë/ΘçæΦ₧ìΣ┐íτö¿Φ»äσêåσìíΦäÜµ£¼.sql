create database if not exists cda;

use cda;

create table if not exists dic_area(
	id int(1) primary key,
	area_id int(6),
	area_name varchar(10),
	parented int(6),
	area_level int(1));

insert into dic_area values
(1,130000,"河北省",100000,1),
(2,130100,"石家庄市",130000,2),
(3,130102,"长安区",130100,3),
(4,130104,"桥西区",130100,3);


select * from dic_area;


-- 查询省代码、省名称、市代码、市名称、县代码、县名称
select t1.area_id 省代码,t1.area_name 省名称,t2.area_id 市代码,t2.area_name 市名称,t3.area_id 县代码,t3.area_name 县名称
from dic_area t1
inner join dic_area t2 on t1.area_id=t2.parented
inner join dic_area t3 on t2.area_id=t3.parented;

