CREATE TABLE `course` (
  `Cno` char(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '课程号（主码）',
  `Cname` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '课程名称',
  `Tno` char(3) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '教工编号（外码）',
  PRIMARY KEY (`Cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='课程表';

CREATE TABLE `score` (
  `Sno` char(3) NOT NULL COMMENT '学号（外码）',
  `Cno` char(5) NOT NULL COMMENT '课程号（外码）',
  `Degree` decimal(4,0) NOT NULL COMMENT '成绩',
  PRIMARY KEY (`Sno`,`Cno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='成绩表';

CREATE TABLE `student` (
  `Sno` char(3) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '学号（主码）',
  `Sname` char(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '学生姓名',
  `Ssex` char(2) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '学生性别',
  `Sbirthday` date DEFAULT NULL COMMENT '学生出生年月',
  `Class` char(5) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '学生所在班级',
  PRIMARY KEY (`Sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生表';

CREATE TABLE `teacher` (
  `Tno` char(3) NOT NULL COMMENT '教工编号（主码）',
  `Tname` char(4) NOT NULL COMMENT '教工姓名',
  `Tsex` char(2) NOT NULL COMMENT '教工性别',
  `Tbirthday` datetime DEFAULT NULL COMMENT '教工出生年月',
  `Prof` char(6) DEFAULT NULL COMMENT '职称',
  `Depart` varchar(10) NOT NULL COMMENT '教工所在部门',
  PRIMARY KEY (`Tno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `course` (`Cno`, `Cname`, `Tno`) VALUES ('3-105','计算机导论','825');
INSERT INTO `course` (`Cno`, `Cname`, `Tno`) VALUES ('3-245','操作系统','804');
INSERT INTO `course` (`Cno`, `Cname`, `Tno`) VALUES ('6-166','数字电路','856');
INSERT INTO `course` (`Cno`, `Cname`, `Tno`) VALUES ('9-888','高等数学','831');

INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('101','3-105','64');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('101','6-166','85');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('103','3-105','92');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('103','3-245','86');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('105','3-105','88');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('105','3-245','75');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('107','3-105','91');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('107','6-166','79');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('108','3-105','78');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('108','6-166','81');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('109','3-105','76');
INSERT INTO `score` (`Sno`, `Cno`, `Degree`) VALUES ('109','3-245','68');

INSERT INTO `student` (`Sno`, `Sname`, `Ssex`, `Sbirthday`, `Class`) VALUES ('101','李军','男','1976-02-20','95033');
INSERT INTO `student` (`Sno`, `Sname`, `Ssex`, `Sbirthday`, `Class`) VALUES ('103','陆君','男','1974-06-03','95031');
INSERT INTO `student` (`Sno`, `Sname`, `Ssex`, `Sbirthday`, `Class`) VALUES ('105','匡明','男','1975-10-02','95031');
INSERT INTO `student` (`Sno`, `Sname`, `Ssex`, `Sbirthday`, `Class`) VALUES ('107','王丽','女','1976-01-23','95033');
INSERT INTO `student` (`Sno`, `Sname`, `Ssex`, `Sbirthday`, `Class`) VALUES ('108','曾华','男','1977-09-01','95033');
INSERT INTO `student` (`Sno`, `Sname`, `Ssex`, `Sbirthday`, `Class`) VALUES ('109','王芳','女','1975-02-10','95031');

INSERT INTO `teacher` (`Tno`, `Tname`, `Tsex`, `Tbirthday`, `Prof`, `Depart`) VALUES ('804','李诚','男','1958-12-02 00:00:00','副教授','计算机系');
INSERT INTO `teacher` (`Tno`, `Tname`, `Tsex`, `Tbirthday`, `Prof`, `Depart`) VALUES ('825','王萍','女','1972-05-05 00:00:00','助教','计算机系');
INSERT INTO `teacher` (`Tno`, `Tname`, `Tsex`, `Tbirthday`, `Prof`, `Depart`) VALUES ('831','刘冰','女','1977-08-14 00:00:00','助教','电子工程系');
INSERT INTO `teacher` (`Tno`, `Tname`, `Tsex`, `Tbirthday`, `Prof`, `Depart`) VALUES ('856','张旭','男','1969-03-12 00:00:00','讲师','电子工程系');

